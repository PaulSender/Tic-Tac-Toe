
/*
* Comp 1050-01 - Computer Science II
* Lab 3 � JavaFx Freeform
* Paul Sender
*/

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;

import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import javafx.stage.Stage;

/**
 * @author Paul Sender
 * @version 1.0.0 2018-03-16 initial version
 * @version 1.0.1 2018-03-25 final version
 * 
 *          Create a class to support interactivity in a JavaFX project This
 *          program will include- One or more stages, one or more scenes, two or
 *          more panes, five or more objects (shapes, buttons, etc.), one or
 *          more bound objects.
 *          <p>
 */

public class Board extends Application {
	private char currentplayer = 'X';
	private Cell[][] cell = new Cell[3][3];
	private Label turnmessage = new Label("It is player one's turn to go");

	/**
	 * Main used to launch
	 * 
	 * @param args
	 *            used to launch application
	 */
	public static void main(String[] args) {
		Application.launch(args);

	}

	/**
	 * start used to set the stage of the application
	 * 
	 * @param primaryStage
	 *            used to set a stage for the application
	 * @throws Exception
	 */
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("FreeForm Application - Tic Tac Toe");
		GridPane board = new GridPane();

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				cell[i][j] = new Cell();
				board.add(cell[i][j], j, i);

			}
		}
		BorderPane border = new BorderPane();
		border.setCenter(board);
		border.setBottom(turnmessage);
		Scene scene = new Scene(border, 500, 500);
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	/**
	 * isFullBoard used to check if the tic-tac-toe board is full
	 * 
	 */
	public Boolean isFullBoard() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (cell[i][j].getPlayer() == ' ') {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * hasWon method used to check if a player has won the game
	 * 
	 * @param player
	 *            is used to check for a character
	 */
	public boolean hasWon(char player) {
		for (int i = 0; i < 3; i++) {
			if (cell[i][0].getPlayer() == player && cell[i][1].getPlayer() == player
					&& cell[i][2].getPlayer() == player) {
				return true;
			}

		}
		for (int i = 0; i < 3; i++) {
			if (cell[0][i].getPlayer() == player && cell[1][i].getPlayer() == player
					&& cell[2][i].getPlayer() == player) {
				return true;
			}
		}
		for (int i = 0; i < 3; i++) {
			if (cell[0][0].getPlayer() == player && cell[1][1].getPlayer() == player
					&& cell[2][2].getPlayer() == player) {
				return true;
			}

		}
		for (int i = 0; i < 3; i++) {
			if (cell[0][2].getPlayer() == player && cell[1][1].getPlayer() == player
					&& cell[2][0].getPlayer() == player) {
				return true;
			}
		}
		return false;
	}

	public class Cell extends Pane {
		private char player = ' ';

		/**
		 * Cell used to create the clickable game board
		 */
		public Cell() {
			setStyle("-fx-border-color :black");
			this.setPrefSize(300, 300);
			this.setOnMouseClicked(e -> handleClick());
		}

		/**
		 * handleClick used to tell the application what to do when the user clicks with
		 * his or her mouse
		 */
		private void handleClick() {
			if (player == ' ' && currentplayer != ' ') {
				setPlayer(currentplayer);
				if (hasWon(currentplayer)) {
					turnmessage.setText(currentplayer + " has won!");
					currentplayer = ' ';
				} else if (isFullBoard()) {
					turnmessage.setText("Stalemate");
					currentplayer = ' ';
				} else {
					currentplayer = (currentplayer == 'X') ? 'O' : 'X';
					turnmessage.setText(currentplayer + "'s turn");
				}
			}
		}

		/**
		 * getPlayer used to return the player that was set
		 */
		public char getPlayer() {
			return player;
		}

		/**
		 * setPlayer used to assign a player to the turn
		 */
		public void setPlayer(char c) {
			player = c;

			if (player == 'X') {
				ImageView x = new ImageView("file:///C:/Users/senderp/Desktop/website/img/ximage.png");
				x.setFitHeight(100);
				x.setFitWidth(100);
				x.setLayoutX(50);
				x.setLayoutY(30);
				getChildren().add(x);
			} else if (player == 'O') {
				ImageView o = new ImageView("file:///C:/Users/senderp/Desktop/website/img/oimage.jpg");
				o.setFitHeight(100);
				o.setFitWidth(100);
				o.setLayoutX(50);
				o.setLayoutY(30);

				getChildren().add(o);

			}
		}
	}
}
